/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package net.jc_mouse.unlockpattern;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.PreparedStatement;
//import net.jc_mouse.demo.AppDemoJFrame;
/**
 * @web https://www.jc-mouse.net/
 * @author Mouse
 */
public class UnlockPanel extends JPanel implements MouseListener,MouseMotionListener {
        
    private JFrame parent;
    private String myKey="125895";//patron de desbloqueo
    //array para las 9 figuras que forman la matriz
    private ArrayList<FigurePattern> figurePatternArr = new ArrayList();
    //array para las figuras que conforman el patron desbloqueo
    private ArrayList<FigurePattern> pattern= new ArrayList();
    //String para guardar el patron generado por el usuario
    private String password = "";
    //para mostrar imagen de "acceso denegado"
    //private final Image //image = new ImageIcon(getClass().getResource("/net/jc_mouse/unlockpattern/access_denied.jpg")).getImage();
    private boolean showError=false;
    public char[] Ruta;
    public int Longitud;
    public int Final;
    public int Inicial;
    public int Hacer;
    public int variable;
    public int i;
    public ArrayList<String> EnviarRuta = new ArrayList<String>();
    
    public String usuario ="root";
    public String clave="";;
    public String url="jdbc:mysql://localhost:3306/carroautonomo";
    public Connection con;
    public Statement stmt;
    public ResultSet rs;
    
    
    /**
     * Constructor de clas
     * @param parent JFrame que contiene el JPanel
     */
    public UnlockPanel(JFrame parent){                
        this.parent = parent;
        //se agregan 9 circulos al contenedor
        figurePatternArr.add(new FigurePattern(1,0,0));
        figurePatternArr.add(new FigurePattern(2,80,0));
        figurePatternArr.add(new FigurePattern(3,160,0));
        
        figurePatternArr.add(new FigurePattern(4,0,80));
        figurePatternArr.add(new FigurePattern(5,80,80));
        figurePatternArr.add(new FigurePattern(6,160,80));
        
        figurePatternArr.add(new FigurePattern(7,0,160));
        figurePatternArr.add(new FigurePattern(8,80,160));
        figurePatternArr.add(new FigurePattern(9,160,160));
        
        //Eventos del raton        
        UnlockPanel.this.addMouseListener( UnlockPanel.this );        
        UnlockPanel.this.addMouseMotionListener( UnlockPanel.this);        
    }
    
   @Override
    public void paintComponent(Graphics g){    
        Graphics2D g2 =(Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);            
        g2.setColor( new Color(0,0,0) );
        g2.fill(new Rectangle2D.Double(0,0,getWidth(),getHeight()));  
        
        //dibuja las lineas del patron de desbloqueo entre los circulos
        Point point = null;
        for(FigurePattern figurePattern: pattern){
            g2.setStroke( new BasicStroke( 20 ) );
            g2.setColor( new Color(204,204,204) );
            if(point!=null)
                g2.drawLine(point.x, point.y, figurePattern.getCenterPoint().x, figurePattern.getCenterPoint().y);  
             point = figurePattern.getCenterPoint();            
        }
        
        //dibuja los circulos para los patrones de desbloqueo       
        if(figurePatternArr!=null)
            figurePatternArr.stream().forEach((b) -> {
                b.draw(g2);
        });  
        
        //muestra error 
        if(showError){
            //g2.drawImage(image, (getWidth()-220)/2, (getHeight()-93)/2, 220, 93, null);         
        }  
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {}

    @Override
    public void mousePressed(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {  
       checkUnlockPattern();
    }

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void mouseDragged(MouseEvent e) {
        //cuando se arrastra el cursor del mouse
        figurePatternArr.stream().filter((p) -> ( 
            FigurePattern.insideArea(p.getArea(),e.getPoint()) )).forEach((p) -> {
            if(this.pattern.isEmpty()){//Si esta vacio se añade objeto
                pattern.add(p);//añade a array
                p.setSelected(true);//cambia color
                password +=p.getKey();//concatena valor de figura
            }else{//Si ya existen objetos en el array
                //se comprueba que objeto nuevo no se repita con el ultimo añadido
                if(pattern.get(pattern.size()-1).getKey() != p.getKey()){
                    pattern.add(p);//añade a array
                    p.setSelected(true);//cambia color
                    password +=p.getKey(); //concatena valor de figura
                }
            }
        });
        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) { showError=false; repaint();}
    
    /**
     * metodo para comprobar que patron de desbloqueo es correcto
     * de ser asi -> abre nuevo formulario
     * caso contrario -> muestra mensaje de error
     */
    public void checkUnlockPattern(){ 
        PreparedStatement ps;
        String sql;
        Ruta=password.toCharArray();
        Longitud=Ruta.length;
            Longitud--;
            Final = Character.getNumericValue(Ruta[Longitud]);
            Inicial = Character.getNumericValue(Ruta[0]);
            if(Inicial==7 ){
                if(Final==3)
                {
                    
                     JOptionPane.showMessageDialog(null,
                "Ruta enviada",
                "PopUp Dialog",
                JOptionPane.INFORMATION_MESSAGE);
                     //cuatro(0);
                
                  for(i=0;i<Ruta.length;i++){
                    
                          Hacer = Character.getNumericValue(Ruta[i]);
                          
                    switch (Hacer){
                          case 1:  
                                    uno(i-1,i-2);
                                    break;
                          case 2:  
                                     dos(i-1,i-2);
                                     break;
                          case 3:  
                                     tres(i-1,i-2);
                                     break;
                          case 4:  
                                     if(i-1==0){
                                         cuatro(i-1,i-1);
                                     }else{
                                         cuatro(i-1,i-2);
                                     }
                                     break;
                          case 5:    
                                     if(i-1==0){
                                         cinco(i-1,i-1);
                                     }
                                     break;
                          case 6:  
                                     break;
                          case 7:  
                                     break;
                          case 8:    
                                     if(i-1==0){
                                         ocho(i-1,i-1);
                                     }
                                     break;
                          default: 
                                     break;
                         
                    }
                 }
                
                try {
                        Class.forName("com.mysql.cj.jdbc.Driver");
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(UnlockPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }
        
                try {
                        con=DriverManager.getConnection(url,usuario,clave);
                        stmt=con.createStatement(); 
                        
                        stmt.executeUpdate("DELETE FROM carroaut");
                        
                        for(int i=0;i<EnviarRuta.size();i++)
                            {
                                sql = "INSERT INTO carroaut VALUES(?,?,?)";
                                ps = con.prepareStatement(sql);
                                ps.setString(1, null);
                                ps.setInt(2, 0);
                                ps.setString(3,EnviarRuta.get(i));
                                ps.executeUpdate();
                                //stmt.executeUpdate("INSERT INTO carroaut VALUES(null,0,i)");
                                //System.out.println(EnviarRuta.get(i));
                            }
                    } catch (SQLException ex) {
                        Logger.getLogger(UnlockPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }  
                     
             } else{            
               //showError=true;
               JOptionPane.showMessageDialog(null,
                "El final de la ruta es incorrecta",
                "PopUp Dialog",
                JOptionPane.INFORMATION_MESSAGE);
            }
            } else{
                JOptionPane.showMessageDialog(null,
                "El inicio de la ruta es incorrecta",
                "PopUp Dialog",
                JOptionPane.INFORMATION_MESSAGE);
            }
        pattern.clear();//limpia movimientos antiguos
        password="";//resetea password
        //reinicia valor para objetos
        figurePatternArr.stream().forEach((b) -> {
            b.setSelected(false);
        });
        repaint();
        EnviarRuta.clear();
    }
    
    
    
    public void uno(int Actual, int Anterior){
        switch (Character.getNumericValue(Ruta[Actual])){
                          case 2:  
                   
                                    break;
                          case 4:  
                                     switch (Character.getNumericValue(Ruta[Anterior])){
                                        case 1:  
                                                EnviarRuta.add("180");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 2:  
                                                EnviarRuta.add("DERECHA135");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 5:  
                                                EnviarRuta.add("DERECHA90");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 7: 
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 8:  
                                                EnviarRuta.add("DERECHA45");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        default: 
                                                 break;
                                    }
                                     break;
                          case 5:    
                                    break; 
                          default: 
                                     break;
                         
                    }
    }
    
    public void dos(int Actual, int Anterior){
        if(Ruta[Actual]=='1' && Ruta[Anterior]=='4'){
               EnviarRuta.add("DERECHA90");
               EnviarRuta.add("ADELANTE");
        }
    }
    
    public void tres(int Actual, int Anterior){
        if(Ruta[Actual]=='2' && Ruta[Anterior]=='1'){
               EnviarRuta.add("ADELANTE");
        }
    }
    
    public void cuatro(int Actual, int Anterior){
        if(Actual==Anterior){
            EnviarRuta.add("ADELANTE");
        }else{
               switch (Character.getNumericValue(Ruta[Actual])){
                          case 1:  
                                    switch (Character.getNumericValue(Ruta[Anterior])){
                                        case 2:  
                                                EnviarRuta.add("IZQUIERDA90");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 5:
                                                EnviarRuta.add("IZQUIERDA135");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 4:
                                                EnviarRuta.add("180");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        default: 
                                                 break;
                                    }
                                    break;
                          case 2:  
                                     switch (Character.getNumericValue(Ruta[Anterior])){
                                        case 1:  
                                                EnviarRuta.add("DERECHA135");
                                                EnviarRuta.add("ADELANTEH");
                                                break;
                                        case 3:
                                                EnviarRuta.add("IZQUIERDA45");
                                                EnviarRuta.add("ADELANTEH");
                                                break;
                                        case 4:
                                                EnviarRuta.add("180");
                                                EnviarRuta.add("ADELANTEH");
                                                break;
                                        case 5:
                                                EnviarRuta.add("IZQUIERDA135");
                                                EnviarRuta.add("ADELANTEH");
                                                break;
                                        case 6:
                                                EnviarRuta.add("IZQUIERDA90");
                                                EnviarRuta.add("ADELANTEH");
                                                break;
                                        default: 
                                                 break;
                                    }
                                     break;
                          case 5:    
                                     switch (Character.getNumericValue(Ruta[Anterior])){
                                        case 1:  
                                                EnviarRuta.add("DERECHA135");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 2:
                                                EnviarRuta.add("DERECHA90");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 3:
                                                EnviarRuta.add("DERECHA45");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 4:
                                                EnviarRuta.add("180");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 6:
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 7:
                                                EnviarRuta.add("IZQUIERDA135");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 8:
                                                EnviarRuta.add("IZQUIERDA90");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 9:
                                                EnviarRuta.add("IZQUIERDA45");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        default: 
                                                 break;
                                    }
                                     break;
                          case 7:    
                                     switch (Character.getNumericValue(Ruta[Anterior])){
                                        case 4:  
                                                EnviarRuta.add("180");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 5:
                                                EnviarRuta.add("DERECHA135");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        case 8:
                                                EnviarRuta.add("DERECHA90");
                                                EnviarRuta.add("ADELANTE");
                                                break;
                                        default: 
                                                 break;
                                    }
                                     break;
                          case 8:   
                                     switch (Character.getNumericValue(Ruta[Anterior])){
                                        case 4:  
                                                EnviarRuta.add("180");
                                                EnviarRuta.add("ADELANTEH");
                                                break;
                                        case 5:
                                                EnviarRuta.add("DERECHA135");
                                                EnviarRuta.add("ADELANTEH");
                                                break;
                                        case 6:
                                                EnviarRuta.add("DERECHA90");
                                                EnviarRuta.add("ADELANTEH");
                                                break;
                                        case 7:
                                                EnviarRuta.add("IZQUIERDA135");
                                                EnviarRuta.add("ADELANTEH");
                                                break;
                                        case 9:
                                                EnviarRuta.add("DERECHA45");
                                                EnviarRuta.add("ADELANTEH");
                                                break;
                                        default: 
                                                 break;
                                    }
                                     break;
                          default: 
                                     break;
                         
                    }
        }
        
    }
    
    public void cinco(int Actual, int Anterior){
        if(Actual==Anterior){
            EnviarRuta.add("DERECHA45");
            EnviarRuta.add("ADELANTEH");
        }
    }
    
    public void ocho(int Actual, int Anterior){
        if(Actual==Anterior){
            EnviarRuta.add("DERECHA90");
            EnviarRuta.add("ADELANTE");
        }
    }
}//end